:- use_module(library(clpfd)).
:- use_module(library(clpr)).

abeceda([a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z]).

rotiraj(0, X, X).
rotiraj(N, [H|T], B) :-
	N #>= 0,
	M #= N - 1,
	append(T, [H], A),
	rotiraj(M, A, B).
	
preslikaj([], _, _, _) :-
	false.
preslikaj(_, [], _, _) :-
	false.
preslikaj([A|TA], [B|TB], X, Y) :-
	X = A,
	Y = B;
	preslikaj(TA, TB, X, Y).

cezar(_, [], []).
cezar(N, [X|I], [Y|O]) :-
	abeceda(A),
	rotiraj(N, A, B),
	preslikaj(A, B, X, Y),
	cezar(N, I, O).

% izpitjeprelahek
bruteforce(In, Out) :-
	cezar(N, In, Out),
	N in 0..25.